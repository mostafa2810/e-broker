/// Choosing this method because using proper state management would be an
/// overkill for the scope of this project.
class AudioState {
  AudioState._();
  static List<String> files = [];
}
