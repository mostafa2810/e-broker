class Strings {
  static const String invalidEmailMessage = 'Please enter valid email address';
  static const String emptyEmailMessage = 'Please enter email';
  static const String emptyValueMessage = 'Please enter some text';
  static const String invalidNameMessage = 'Please enter only alphabets';
  static const String invalidPhoneMessage = 'Please enter valid Phone Number';
  static const String emptySlugIdMessage = 'Please enter valid slug id';
  static const String invalidSlugIdMessage = 'Please enter valid slug id';
}
