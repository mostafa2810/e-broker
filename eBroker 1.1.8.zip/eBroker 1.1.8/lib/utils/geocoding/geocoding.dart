abstract class GeocodingProvider {}
